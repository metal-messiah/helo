module.exports = {
    domain:"jporter-helo.auth0.com",
    clientID:"OSgtAd6oM1Wl5luEo6ebq6NJjA3VYh9O",
    clientSecret:"AC6hd91Ea6ZSfL7uwVrg7ZXfRKxgxcG9y2_GnHFUQ76iyc1fUOsmIOqSobYJ2wIm"
}